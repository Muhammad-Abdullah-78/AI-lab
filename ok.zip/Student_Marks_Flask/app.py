from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# Dataset load
student = pd.read_csv(
    r"C:\Users\DELL\Desktop\AI lab tasks (007)\student_marks_prediction_dataset.csv"
)

# Null values fill
student = student.fillna(student.mean(numeric_only=True))

# Object columns ko int me convert
cat_columns = student.select_dtypes(['object']).columns
student[cat_columns] = student[cat_columns].apply(
    lambda x: pd.factorize(x)[0]
)

# Int type conversion
student = student.astype(int)

# X and Y
X = student.iloc[:, 0:-1]
Y = student.iloc[:, -1]

# Train test split
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=42
)

# Model train
model = RandomForestClassifier()
model.fit(X_train, Y_train)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    hours = int(request.form['hours'])
    attendance = int(request.form['attendance'])
    assignment = int(request.form['assignment'])
    exam_score = int(request.form['exam_score'])

    input_data = [[hours, attendance, assignment, exam_score]]

    prediction = model.predict(input_data)

    return render_template(
        'index.html',
        prediction_text=f"Predicted Marks Category: {prediction[0]}"
    )


if __name__ == "__main__":
    app.run(debug=True)

